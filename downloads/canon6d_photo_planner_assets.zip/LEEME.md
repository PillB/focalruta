# FocalRuta · recursos para llevar

Seis planes fotográficos por Lima para Canon EOS 6D, listos para usar sin conexión.

## Qué hay aquí

- `plans/plan_a.html` … `plan_f.html`: cada plan con sus 10 tomas, diagramas y
  ajustes para día, tarde y noche. Se abren en cualquier navegador, también en el
  iPhone desde la app Archivos.
- `field_card.html`: la tarjeta de campo para imprimir o llevar en el teléfono.
- `diagrams/`: los 120 diagramas de las tomas (persona y perro) y 11 diagramas de
  composición y comparación de lentes, en PNG para imprimir.
- `data/plans.json`: todos los datos de los planes, por si quieres usarlos en otra
  herramienta.

## Cómo leer los ajustes

Cada toma trae ajustes distintos para día, tarde y noche. Están calculados para la
luz típica de cada escena (tabla de valores de exposición ANSI PH2.7) y, cuando hace
falta, indican el filtro ND necesario (por ejemplo, «ND de 6 pasos (ND64)»). Si una
toma dice «no viable» a esa hora, cámbiala de horario. Son un punto de partida:
haz una foto de prueba y revisa el histograma.

La profundidad de campo usa un círculo de confusión de 0.03 mm, la convención
habitual para full frame; tómala como guía de planificación, no como un borde exacto.
